import { Container, Toolbar, Typography } from '@mui/material';
import React from 'react';

const Pay = () => {
  return (
    <Container>
      <Toolbar />
      <Toolbar />
      <Typography variant="h4" sx={{ fontFamily: 'var(--dosis-font)', color: "var(--color)" }}>Payment system is coming soon...</Typography>
    </Container>
  );
};

export default Pay;