const firebaseConfig = {
  apiKey: "AIzaSyBLt11088v-t1cyVwkXRgAH5FXoyvWkJgs",
  authDomain: "mi-shop-ceee7.firebaseapp.com",
  projectId: "mi-shop-ceee7",
  storageBucket: "mi-shop-ceee7.appspot.com",
  messagingSenderId: "721117479692",
  appId: "1:721117479692:web:0982c371a45500479eff29"
};
export default firebaseConfig;